# Modules supplantés — non branchés volontairement

Contrairement au comparateur, au screener de dividendes, au mode Simple/Pro et
aux ratios fondamentaux — qui étaient de vraies fonctionnalités terminées mais
jamais chargées, et qui sont désormais actives — les fichiers ci-dessous ne sont
pas des sections manquantes. Les brancher créerait un conflit.

## recommandation.js (28 Ko)

Implémentation parallèle de la vue Recommandations. Elle exige un balisage
entièrement différent de celui en place (`recoTable`, `topPicksGrid`,
`tickerSelect`, `recoDetailCard`, `chartMacd`, `chartBoll`), alors que
`view-analyses` dispose déjà de sa propre implémentation fonctionnelle
(`renderAnalyses`, recherche, filtres Achat / Conserver / Vendre).

Deux versions d'une même vue coexistaient donc, l'ancienne n'étant plus chargée.
Si vous préférez cette version, il faut remplacer le contenu de `view-analyses`
par son balisage — c'est un choix produit, pas une correction.

## presets.js

Préréglages d'analyse technique (`AT_PRESETS`). Aucune fonction du projet ne
lit cette constante : le module n'a jamais été relié au moteur d'analyse
technique. À brancher lorsque la fonctionnalité de préréglages sera spécifiée.

## Portefeuille.css

Feuille de style jamais référencée. Les styles du portefeuille effectivement
appliqués proviennent de `app/css/portefeuille.css` (minuscule) et de
`variables.css`. Conservée pour comparaison avant suppression définitive.
