# États financiers

Saisie et validation des données financières annuelles.

## Fichiers

- `financials.js`
