# Marché

Indices BRVM et déclenchement du scraping de séance.

## Fichiers

- `indices.js`
- `scraper.js`
