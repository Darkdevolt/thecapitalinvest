# Tableau de bord

Vue d'accueil de l'administration et cartes de synthèse.

## Fichiers

- `dashboard-overview.js`
- `dashboard.js`
