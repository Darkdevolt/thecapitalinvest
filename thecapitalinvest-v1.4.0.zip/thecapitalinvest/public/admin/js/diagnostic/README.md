# Diagnostic

Contrôles de cohérence des données de marché.

## Fichiers

- `diagnostic.js`
