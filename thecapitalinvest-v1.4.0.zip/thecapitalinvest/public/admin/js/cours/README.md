# Cours

Saisie, édition, contrôle et historique des cotations. Six fichiers issus de correctifs successifs : `cours.js` porte la vue principale, les autres greffent des comportements à l'exécution.

## Fichiers

- `admin-cours-historique-unified.js`
- `cours-control-editor.js`
- `cours-control.js`
- `cours-historique.js`
- `cours-history-entry-delete.js`
- `cours.js`
