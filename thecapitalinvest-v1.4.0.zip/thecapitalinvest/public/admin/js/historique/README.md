# Historique

Consultation de l'historique des cotations, contrôle qualité et suppression de séance.

## Fichiers

- `historique-quality.js`
- `historique-session-delete.js`
- `historique.js`
