# Séances

Gestion des séances de bourse : CRUD, vue annuelle, vue globale, détails et contrôles d'intégrité.

## Fichiers

- `seance.js`
- `seances-annuel.js`
- `seances-crud.js`
- `seances-details.js`
- `seances-globales-actions.js`
- `seances-globales.js`
- `seances-integrity-hardening.js`
