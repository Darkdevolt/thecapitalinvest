# Dividendes

Calendrier de détachement et de paiement.

## Fichiers

- `dividendes.js`
