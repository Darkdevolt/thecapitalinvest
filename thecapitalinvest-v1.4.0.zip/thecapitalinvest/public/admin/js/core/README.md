# Socle

Configuration Supabase, couche d'appel API, utilitaires partagés et amorçage de l'interface. Chargé en premier : tout le reste en dépend.

## Fichiers

- `api.js`
- `config.js`
- `main.js`
- `utils.js`
