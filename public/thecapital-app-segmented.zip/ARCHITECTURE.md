# Architecture The Capital — Segmentation app.html

## Structure finale

```
public/
├── app.html              ← HTML shell (62 KB, -73% vs original)
├── app/
│   ├── css/
│   │   ├── variables.css     (1.5 KB)  — :root + base body
│   │   ├── base.css          (10.6 KB) — layout, sidebar, header, nav, toast
│   │   ├── components.css    (5.0 KB)  — cards, tables, pills, charts, search
│   │   ├── views.css         (9.2 KB)  — fiche, boc, analyse, portefeuille...
│   │   └── technique.css     (18.3 KB) — analyse technique complète
│   │
│   └── js/
│       ├── main.js           (7.2 KB)  — Auth, loadAll, init
│       ├── state.js          (0.9 KB) — Variables globales
│       ├── api.js            (5.2 KB)  — Supabase client + sb()
│       ├── router.js         (7.3 KB)  — nav(), hash, breadcrumb
│       ├── ui.js             (4.1 KB) — sortTable + helpers
│       ├── utils.js          (4.7 KB) — fmt, fmtDate, fmtM, chartOpts
│       ├── search.js         (2.5 KB) — Global search
│       │
│       ├── components/
│       │   ├── header.js     (0.5 KB) — Header logic
│       │   ├── sidebar.js    (0.4 KB) — Sidebar (hidden)
│       │   └── cards.js      (0.8 KB) — Card renderers
│       │
│       └── views/
│           ├── overview.js       (6.7 KB) — Tableau de bord
│           ├── titres.js         (2.4 KB) — Liste des titres
│           ├── fiche.js          (8.8 KB) — Fiche détaillée
│           ├── boc.js            (3.8 KB) — Bulletin Officiel
│           ├── analyses.js       (5.4 KB) — Recommandations
│           ├── screener.js       (2.4 KB) — Filtres BRVM
│           ├── portefeuille.js   (3.4 KB) — Positions simulées
│           ├── alertes.js        (3.2 KB) — Alertes prix
│           ├── financials.js     (8.9 KB) — États financiers
│           ├── publications.js   (4.2 KB) — Calendrier publications
│           ├── formation.js      (0.9 KB) — Centre de formation
│           ├── analyse-fondamentale.js (10.3 KB) — DCF, TCAM
│           │
│           └── technique/          ← Analyse Technique isolée
│               ├── index.js        (7.2 KB) — Entry point AT
│               ├── engine.js       (22.9 KB) — Canvas 2D renderer
│               ├── draw.js         (3.4 KB) — Outils de dessin
│               ├── crosshair.js    (0.9 KB) — Curseur + tooltip
│               ├── zoom.js         (8.4 KB) — Zoom/pan/resize
│               ├── types.js        (0.3 KB) — Chart types stub
│               ├── indicators.js   (2.5 KB) — Registry modal
│               ├── signals.js      (2.6 KB) — Génération signaux
│               ├── watchlist.js    (3.9 KB) — Watchlist + axes
│               ├── compare.js      (0.9 KB) — Comparaison
│               ├── export.js       (2.4 KB) — PNG + rapport
│               ├── focus.js        (1.0 KB) — Mode focus
│               └── ind/            — Indicateurs individuels
│                   ├── base.js     (0.5 KB)
│                   ├── sma.js      (0.4 KB)
│                   ├── ema.js      (0.4 KB)
│                   ├── bb.js       (0.6 KB)
│                   ├── rsi.js      (0.8 KB)
│                   ├── macd.js     (0.5 KB)
│                   ├── stoch.js    (0.8 KB)
│                   ├── adx.js      (1.0 KB)
│                   ├── cci.js      (0.6 KB)
│                   ├── vwap.js     (0.4 KB)
│                   ├── obv.js      (0.4 KB)
│                   └── ha.js       (0.7 KB)
│
├── admin/                ← INCHANGÉ
├── login.html            ← INCHANGÉ
├── register.html         ← INCHANGÉ
├── about.html            ← INCHANGÉ
├── contact.html          ← INCHANGÉ
├── features.html         ← INCHANGÉ
├── index.html            ← INCHANGÉ
├── marche.html           ← INCHANGÉ
├── markets.html          ← INCHANGÉ
├── platform.html         ← INCHANGÉ
├── pricing.html          ← INCHANGÉ
├── portefeuille.html     ← INCHANGÉ
├── screener.html         ← INCHANGÉ
├── style.css             ← INCHANGÉ
├── nav.js                ← INCHANGÉ
└── ...                   ← Tout le reste INCHANGÉ
```

## Statistiques

| Métrique | Valeur |
|----------|--------|
| Fichiers créés | 52 |
| Taille totale | 258 KB |
| Original app.html | 229 KB |
| Nouveau app.html | 62 KB (-73%) |
| Modules JS | 28 |
| Fichiers CSS | 5 |
| Indicateurs AT | 11 fichiers individuels |

## Ordre de chargement dans app.html

1. **CSS** : variables → base → components → views → technique
2. **Core JS** : utils → state → api → router → ui → search
3. **Components** : header → sidebar → cards
4. **Views** : toutes les vues (overview → ... → formation)
5. **AT** : indicators (base, sma, ema, bb, rsi, macd, stoch, adx, cci, vwap, obv, ha) → engine → draw → crosshair → zoom → types → indicators → signals → watchlist → compare → export → focus → index
6. **Entry** : main.js (auth + init)

## Notes importantes

- Toutes les fonctions globales sont préservées (pas de modules ES6)
- Le code fonctionne exactement comme avant, juste segmenté
- L'analyse technique (~40% du code JS) est complètement isolée
- Les fichiers sont prêts pour une future migration ES6/modules
